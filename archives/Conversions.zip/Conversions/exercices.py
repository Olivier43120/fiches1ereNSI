# Exercice 1
def est_binaire(s): 
    for c in s:
        if c .........:
            return False 
    return .........

# Tests unitaires
assert est_binaire('1001011') is True
assert est_binaire('00100020') is False
assert est_binaire('') is True
assert est_binaire('abc') is False


# Exercice 2
def inverser(s): 
    r = ""
    for c in s: 
        r =
    return r

# Tests unitaires
assert inverser('chaton') == 'notahc'
assert inverser('101110') == '011101'
assert inverser('') == ''
assert inverser('a') == 'a'


# Exercice 3
def bin_vers_dec(s):
    valeur = ......
    for c in s:
        valeur = valeur * ...... + ......
    return valeur

# Tests unitaires
assert bin_vers_dec("0") == 0
assert bin_vers_dec("1") == 1
assert bin_vers_dec("1101") == 13 
assert bin_vers_dec("10110101") == 181
assert bin_vers_dec("00001101") == 13 # zéros à gauche : sans effet 


# Exercice 4
def bin_vers_dec_v2(s): 
    n = len(s)
    total = 0
    for i in range(...):
        # s[i] a pour poids 2 puissance (n - 1 - i) 
        total = total + ...... * ... ** ......
    return total

# Tests unitaires
assert bin_vers_dec_v2("0") == 0
assert bin_vers_dec_v2("1") == 1
assert bin_vers_dec_v2("1101") == 13 
assert bin_vers_dec_v2("10110101") == 181
assert bin_vers_dec_v2("00001101") == 13 # zéros à gauche : sans effet 


# Exercice 5
def dec_vers_bin(n):
    if n == ...: 
        return "0"
    resultat = "" 
    while .........:
        reste = ......
        n = ......
        resultat = ......
    return resultat

# Tests unitaires
assert dec_vers_bin(0) == '0'
assert dec_vers_bin(1) == '1'
assert dec_vers_bin(2) == '10'
assert dec_vers_bin(13) == '1101'
assert dec_vers_bin(181) == '10110101'


# Exercice 6
def dec_vers_bin_8(n):
    s = dec_vers_bin(n) 
    while .........:
        s = .........
    return s

# Tests unitaires
assert dec_vers_bin_8(0) == '00000000'
assert dec_vers_bin_8(5) == '00000101'
assert dec_vers_bin_8(255) == '11111111'


# Exercice 7
CHIFFRES = "0123456789ABCDEF"

def valeur_chiffre(c): # "B" -> 11 
    return CHIFFRES.........

def chiffre_valeur(v): # 11 -> "B" 
    return CHIFFRES[.........]

# Tests unitaires
assert valeur_chiffre('0') == 0
assert valeur_chiffre('9') == 9
assert valeur_chiffre('A') == 10
assert valeur_chiffre('B') == 11
assert valeur_chiffre('F') == 15
assert chiffre_valeur(0) == '0'
assert chiffre_valeur(10) == 'A'
assert chiffre_valeur(11) == 'B'
assert chiffre_valeur(15) == 'F'


# Exercice 8
def hex_vers_dec(s): 
    s = s.upper()
    valeur = 0 
    for c in s:
        .........
        valeur = valeur * ......... + .........
    return valeur

# Tests unitaires
assert hex_vers_dec('0') == 0
assert hex_vers_dec('A') == 10
assert hex_vers_dec('B5') == 181
assert hex_vers_dec('b5') == 181
assert hex_vers_dec('FF') == 255


# Exercice 9
def dec_vers_hex(n): 
    if n == 0:
        return "0" 
    resultat = ""
    while n > 0: 
        resultat = ......... + resultat
        n = ......
    return resultat

# Tests unitaires
assert dec_vers_hex(0) == '0'
assert dec_vers_hex(10) == 'A'
assert dec_vers_hex(11) == 'B'
assert dec_vers_hex(181) == 'B5'
assert dec_vers_hex(255) == 'FF'


# Exercice 10
def vers_decimal(s, b): 
    valeur = 0
    for c in s:
        valeur = valeur * ......... + valeur_chiffre(c)
    return valeur
 
def depuis_decimal(n, b): 
    if n == 0:
        return "0" 
    resultat = ""
    while n > 0:
        resultat = CHIFFRES[......] + resultat
        n = ......
    return resultat

# Tests unitaires
assert vers_decimal('10110101', 2) == 181
assert vers_decimal('B5', 16) == 181
assert depuis_decimal(0, 2) == '0'
assert depuis_decimal(13, 2) == '1101'
assert depuis_decimal(181, 16) == 'B5'
assert depuis_decimal(255, 16) == 'FF'


# Exercice 11
def bin_vers_hex(s):
    # 1) compléter à gauche avec des 0 pour obtenir un multiple de 4 
    while ......... :
        s = "0" + s 
    resultat = ""
    # 2) parcourir la chaîne par paquets de 4
    for i in range(0, len(s), ......):
        paquet = s[i:......]
        resultat = resultat + CHIFFRES[......]
    return resultat

# Tests unitaires
assert bin_vers_hex('0') == '0'
assert bin_vers_hex('1010') == 'A'
assert bin_vers_hex('10110101') == 'B5'
assert bin_vers_hex('1111111') == '7F'


# Exercice 12
def hex_vers_bin(s): 
    resultat = ""
    for c in s: 
        v = ......
        bits = ......
        while len(bits) < ...:
            bits = "0" + bits 
        resultat = resultat + bits
    return resultat

# Tests unitaires
assert hex_vers_bin('0') == '0000'
assert hex_vers_bin('7') == '0111'
assert hex_vers_bin('B5') == '10110101'


# DEFIS

# Exercice 13
def couleur_vers_rgb(code): # code = "#FF8800" 
    rouge = hex_vers_dec(code[1:......])
    vert = hex_vers_dec(code[...... : 5])
    bleu = hex_vers_dec(code[...... : ......])
    return (rouge, vert, bleu) # -> (255, 136, 0)

# Tests unitaires
assert couleur_vers_rgb('#FF8800') == (255, 136, 0)
assert couleur_vers_rgb('#000000') == (0, 0, 0)
assert couleur_vers_rgb('#FFFFFF') == (255, 255, 255)


def rgb_vers_couleur(r, g, b):
    # à vous !

# Tests unitaires
assert rgb_vers_couleur(255, 136, 0) == '#FF8800'
assert rgb_vers_couleur(0, 0, 0) == '#000000'
assert rgb_vers_couleur(255, 255, 255) == '#FFFFFF'
assert rgb_vers_couleur(10, 11, 12) == '#0A0B0C'

# Exercice 14
def addition_binaire(a, b): 
    n = max(len(a), len(b)) 
    while len(a) < n:
        a = "0" + a
    while len(b) < n: 
        b = "0" + b
    retenue = 0
    resultat = ""
    for i in range(n - 1, ......, -1):
        somme = int(a[i]) + int(b[i]) + ......
        resultat = str(......) + resultat
        retenue = ......
    if ......... :
        resultat = "1" + resultat 
    return resultat

# Tests unitaires
assert addition_binaire('0', '0') == '0'
assert addition_binaire('1', '1') == '10'
assert addition_binaire('1010', '1011') == '10101'
assert addition_binaire('1111', '0001') == '10000'
assert addition_binaire('101', '10') == '111'


# Pour aller plus loin
def est_valide(chaine,base):
    # à vous !

# Tests unitaires pour est_valide
assert est_valide('101101', 2) is True
assert est_valide('10201', 2) is False
assert est_valide('B5', 16) is True
assert est_valide('G5', 16) is False
assert est_valide('123', 10) is True
assert est_valide('12A', 10) is False

def oppose_8bits(nb):
    # à vous !

# Tests unitaires pour oppose_8bits
assert oppose_8bits(0) == '00000000'
assert oppose_8bits(5) == '11111011'
assert oppose_8bits(1) == '11111111'
assert oppose_8bits(255) == '00000001'


def decimaux_vers_binaire(nb):
    # à vous !

# Tests unitaires : nombres décimaux en binaire
assert decimaux_vers_binaire(0.625) == "0.101"
assert decimaux_vers_binaire(0.5) == "0.1"
assert decimaux_vers_binaire(0.25) == "0.01"
assert decimaux_vers_binaire(0.75) == "0.11"
assert decimaux_vers_binaire(0.125) == "0.001"
