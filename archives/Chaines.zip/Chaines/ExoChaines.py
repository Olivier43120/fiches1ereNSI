def pluriel_1(mot):
    ...
    
assert pluriel_1('chat') == 'chats'
assert pluriel_1('avion') == 'avions'
assert pluriel_1('souris') == 'souriss'

def pluriel_2(mot):
    if ...... == "s": # Vérifier si la dernière lettre est un s
        return ...
    else:# cas général
        return ...
    
assert pluriel_2('chat') == 'chats'
assert pluriel_2('avion') == 'avions'
assert pluriel_2('souris') == 'souris'

def pluriel_3(mot):
    if ............. :
        return ...
    else:
        return ...

    
assert pluriel_3('maison') == 'maison'
assert pluriel_3('riz') == 'riz'
assert pluriel_3('prix') == 'prix'
assert pluriel_3('nez') == 'nez'

def pluriel_4(mot):
    if mot[...] == ...:# on regarde les 2 dernières lettres
        return mot[...] + ...# on rajoute 'aux' à la place de 'al'
    else:
        if ......... :
            return mot
        else:
            return mot + "s"

assert pluriel_4('cheval') == chevaux
assert pluriel_4('souris') == souris
assert pluriel_4('perdrix') == perdrix
assert pluriel_4('maison') == maisons


def affiche_conjugaison(verbe):
    if ... != ...:
        return "Ce n'est pas un verbe du premier groupe"
    else:
        return "je "+...+"e \ntu "+...........

# A vous de vérifier

def hamming(mot1,mot2):
    compteur = ...
    for k in range(len(mot1)):
        if ... != ...:
            compteur = ...
    return compteur

assert hamming("japon","savon") == 2
assert hamming("renardeau","lecorbeau") == 4

def latin_cochon(mot):
    if mot[0] in ...: # test d'appartenance
        return ...
    else:
        return ...

assert latin_cochon('VITRE') == "ITREVUM"
assert latin_cochon('BLANCHE') == "LANCHEBUM"
assert latin_cochon('CARAMEL') == "ARAMELCUM"

def verlan(mot):
    mot2 = ""
    for lettre in mot:
        mot2 = ... + ...
    return mot2

assert verlan('SALUT') == "TULAS"

def presence_de_A(...):
    for lettre in ...:
        if lettre == ...:
            return ...
    return ...

assert presence_de_A('CTTGCT') == False
assert presence_de_A('TAATTACAGACCTGAA') == True

def position_de_AT(chaine):
    compteur = 0
    for k in range(....):
        if chaine[...] == ... and chaine[...] == ...:
            return compteur
        else:
            compteur = ......
            
assert position_de_AT('CTTATGCT') == 3
assert position_de_AT('GATATAT') == 1
assert position_de_AT('GACCGTA') == None

def position(code,sequence):
    compteur = 0
    for k in range(.....):
        if sequence[...:...] == ...:
            return compteur
        else:
            compteur += 1
            
assert position('CCG', 'CTCCGTT') == 2

def lettre_majuscule(lettre):
    nombre = ord(lettre)
    return ...

assert lettre_majuscule("t") == "T"

def majuscules(phrase):
    new_phrase = ""
    for lettre in phrase:
        if ord(lettre) <= ...: # on détecte les lettres qui sont déjà des majuscules et la ponctuation
            new_phrase = .....
        else: # on gère ici les minuscules
            new_phrase = .....
    return new_phrase

assert majuscules("Bonjour le monde") == "BONJOUR LE MONDE"

def minuscules(phrase):
    new_phrase = ""
    for lettre in phrase:
        if ord(lettre) >= .... or ord(lettre)<= ... : #on gère ici les minuscules et la ponctuation
            new_phrase = .....
        else:
            new_phrase = ..... # on gère ici les majuscules
    return new_phrase

def formate_prenom_nom(personne):
    position_espace = 0
    while ... != " ":
        position_espace = ... # on détecte la position du caractère qui sépare le nom et le prénom
    prenom = personne[...]
    nom = personne[....]
    return ....+....+....+...

assert formate_prenom_nom("hatty potter") == "Harry POTTER"
assert formate_prenom_nom("LORD Voldemort") == "Lord VOLDEMORT"

def occurrences_lettre(lettre,phrase):
    compteur = ...
    for caractere in phrase :
        if ... == ...:
            compteur = ...
    return compteur

assert occurrences_lettre('E', 'ESPRIT ES TU LA') == 2

def nombre_lettres(phrase):
    compteur = 0
    for caractere in phrase :
        if ........ : # detecter les signes de ponctuation à l'aide de la table ASCII et de la fonction ord
            ...
        else:
            ...
    return compteur

assert nombre_lettres("ESPRIT ES TU LA") == 12

def pourcentage_lettre(lettre,phrase):
    return .........

assert pourcentage_lettre("E","ESPRIT ES TU LA") == 16.66


######################################
######################################
##########DERNIERE QUESTION###########
######################################
######################################

texte1 = "TMAIER BERACUO RSU NU REBRA PRCEEH EIANTT NE ONS EBC NU GAOFREM EIMATR RERNAD APR L RDUOE LAHECLE UIL TTNI A EUP SREP EC LGNGAEA TE RBONUJO ERMNOUSI DU UBRACEO QUE OVSU EEST LIJO UQE OUVS EM MSZELBE BAEU ASNS MIERNT IS RVETO AGRAME ES PRARPTOE A OEVTR AMGUPLE VUOS SEET EL PNIHXE DSE OSHET ED CSE BIOS A ESC MSOT LE OUBRCEA NE ES ESTN ASP DE IEJO TE OUPR ERRNOTM AS BELEL XOVI IL OREVU NU RGLEA ECB ILESSA EBOMTR AS PIOER EL NRDAER S EN ISIAST TE ITD MNO NOB EUSRMNOI NRPEEAZP QEU UTOT EUTLRFTA IVT XUA SPNEDE DE UECIL UQI L TECEOU TECET NEOCL VATU BNEI UN GMAEORF SNAS TUOED LE EOABURC OHENTXU TE NSCOFU UJRA SMIA UN EPU TRDA UQ NO EN L Y ARRPEIDNT ULSP"
texte2= "WRE TREITE SO TSPA CUDHR AHNCT UND WIND SE STI RED AEVRT MTI ESEIMN IDNK RE ATH END NEABNK WLOH IN EMD AMR ER AFTSS HIN IHSERC RE AHTL HIN MRWA EINM SHNO SAW SRTIBG UD SO NGBA DNEI EIHSGTC ESISTH RAETV UD DEN LERNIOKG NITHC NDE LOENINKGRE TIM OKRN UDN CHWFSEI NEIM NSOH ES STI IEN BIFTRLSEEEN DU BILESE IKDN OMKM EHG MIT MIR RAG ECHNOS EPELSI EIPSL IHC ITM RDI HNCMA BEUTN MBLUNE DINS NA DEM TNDRAS NMIEE UTETMR AHT CAMHN UDNGEL GDAWEN MIEN EATRV MENI VEART DUN OSTHER DU CINTH SAW KNNOEIREGL RIM ILEES PRSTVRCIEH ISE IHGRU BEEILB RIGUH MNEI KNDI NI RDNEUR NATBRLET STAESUL EDR WNID"
texte3 = "DSNOACAIF ORP ANU DAEDALRI DNAAEIMTI EQU NNCOSETE EL RSTEOUL SMA AACTFAITNS UQE LE TSVAO OINSRVUE DE US ANIGIICANOM EIORDP TOOD RTEIENS RPO LE ITOABOLRROA ED QIUAMALI USOP A NSSRCAEAD LA TMREAAI NXTADAUEE ROP GOARLS EMESS DE NNAMICLUIAPO Y LOVOIV A RES LE RHMEOB EOMDNEERPRD DE LOS RSOPMRIE OMTSIPE UEQ CIIDADE LE RTDAAOZ ED LSA CELSAL Y LA NICOIOPS ED LAS UESVNA SSACA Y ES ITRMNEEOD QEU AERFU EL UEQIN IIIRDEGAR LA NAIORTREICP DE AL RRTEIA"
texte4 = "IMTRUESMME DNA TEH LNGIIV SI EYAS SIFH REA GJPNUIM DNA HET TTNOCO IS GHIH OH OUYR DDADY SI IRHC DAN ROUY MA SI DOGO GKOILON OS USHH LTLIET BBYA NDOT OUY CYR NEO OF HESET GNSRONIM YUO RE NANGO SIER PU SNIGING NAD OULLY EPADRS YUOR GINSW DAN LYOLU KATE OT HET KSY TUB ITLL TATH MGNIRNO EREHT NATI INTGOHN ACN AHMR OYU TWIH DADYD NDA MYMMA NSTIDGAN YB"
