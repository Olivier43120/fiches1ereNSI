# Exercice 1
def moyenne(notes):
    total = 0
    for n in notes.___():
        total = total + ___
    return total / ___(notes)

assert moyenne({"maths": 15, "nsi": 18, "anglais": 12, "histoire": 9}) == 13.5

# Exercice 2
def meilleure_matiere(notes):
    meilleure = None
    note_max = -1
    for matiere, n in notes.items():
        if n ___ note_max:
            note_max = ___
            meilleure = ___
    return meilleure

assert meilleure_matiere({"maths": 15, "nsi": 18, "anglais": 12}) == "nsi"

# Exercice 3
def frequences(mot):
    occ = {}
    for lettre in mot:
        if lettre in ___:
            occ[lettre] = occ[lettre] + ___
        else:
            occ[lettre] = ___
    return occ

assert frequences("banane") == {'b': 1, 'a': 2, 'n': 2, 'e': 1}

# Exercice 4
def compte_mots(phrase):
    compteur = {}
    for mot in phrase.___():
        if mot ___ compteur:
            compteur[mot] += 1
        else:
            compteur[___] = ___
    return compteur

assert compte_mots("il pleut il fait gris il pleut") == {'il': 3, 'pleut': 2, 'fait': 1, 'gris': 1}

# Exercice 5
def lettre_max(mot):
    occ = frequences(mot)
    ...
    ...
    ...
    return ...

# Exercice 6
eleves = [
{"nom": "Alice", "age": 16, "note": 14},
{"nom": "Bob", "age": 17, "note": 9},
{"nom": "Chloé", "age": 16, "note": 17},
{"nom": "David", "age": 17, "note": 12},
]

def moyenne_classe(liste):
    total = 0
    for e in liste:
        total = total + e[___]
    return total / ___(liste)

def noms_admis(liste):
    """Renvoie la liste des noms des élèves ayant au moins 10."""
    resultat = []
    for e in liste:
        if e["note"] ___ 10:
            resultat.___(e[___])
    return resultat


# Exercice 7
def regrouper_par_age(liste):
    groupes = {}
    for e in liste:
        age = e["age"]
        if age not in ___:
            groupes[age] = ___ # liste vide
        groupes[age].___(e["nom"])
    return groupes
print(regrouper_par_age(eleves))

assert regrouper_par_age(eleves) == {16: ['Alice', 'Chloé'], 17: ['Bob', 'David']}

# Exercice 8
def inverser(d):
    inverse = {}
    for cle, valeur in d.___():
        inverse[___] = ___
    return inverse

salles = {"Alice": 101, "Bob": 204, "Chloé": 112}
assert inverser(salles) == {101: 'Alice', 204: 'Bob', 112: 'Chloé'}