# Exercice 1
def somme_elements(tab):
    """
    tab : liste d'entiers
    Sortie : entier - la somme des éléments de la liste tab
    """
    resultat = 0
    for k in range(......):
        resultat = .........
    return resultat

assert somme_elements([5, 2, 7, 3, 1, 8]) == 26, print("Programme faux")



# Exercice 2
def somme_elements_pairs(tab):
    """
    tab : liste d'entiers
    Sortie : entier - la somme des éléments d'indices pairs de la liste tab
    """
    resultat = 0
    for k in range(......):
        if ...... == ......: #test de parité
            resultat = .........
    return resultat

assert somme_elements_pairs([5, 2, 7, 3, 1, 8]) == 13, print("Programme faux")


# Exercice 3
def somme_elements_pairs(tab):
    """
    tab : liste d'entiers
    Sortie : entier - la somme des éléments pairs de la liste tab
    """
    resultat = 0
    for k in range(......):
        if ...... == ......: #test de parité
            resultat = .........
    return resultat

assert somme_elements_pairs([5, 2, 7, 3, 1, 8]) == 10, print("Programme faux")


# Exercice 4
# partie 1
def liste_somme(tab1,tab2):
    """
    tab1 : liste d'entiers
    tab2 : liste d'entiers
    Sortie : la liste des sommes des éléments de tab1 et tab2 ayant le même indice
    """
    L = []
    for k in .........:
        L.....(......)
    return L

assert liste_somme([2, 3, 7], [1, 5, 3]) == [3, 8, 10]

# partie 2
def liste_somme(tab1,tab2):
    """
    tab1 : liste d'entiers
    tab2 : liste d'entiers
    Sortie : la liste des sommes des éléments de tab1 et tab2 ayant le même indice
    """
    L=[]
    if len(tab1) < len(tab2):
        for k in range(len(tab1)):
            L......(...... + ......)
        L = L + .......
    else:
        for k in range(len(tab2)):
            L......(...... + ......)
        L = L + ......
    return L

assert liste_somme([6, 4, 7, 7, 2, 1], [3, 5, 3]) == [9, 9, 10, 7, 2, 1]
assert liste_somme([6, 4], [3, 5, 3, 7, 7, 2, 1]) == [9, 9, 3, 7, 7, 2, 1]


# Exercice 5
def avant_pivot(tab,nb):
    """
    tab : liste d'entiers
    valeur : entier
    Sortie : liste - la liste des valeurs de tab strictement inférieures à valeur
    """
    L = []
    for element in tab:
        if ............:
            L.append(.........)
    return L

assert avant_pivot([6, 8, 2, 4, 9, 12, 5, 11, 0], 7) == [6, 2, 4, 5, 0]


# Exercice 6
def fibo(nb):
    """
    nb : entier positif ou nul (int)
    Sortie : liste - la liste des nb premiers termes de la suite de Fibonacci
    """
    if nb == 0:
        return [0]
    elif nb == 1:
        return [0,1]
    else:
        L = [0,1]
        a = 0
        b = 1
        for k in range(...):
            c = ...
            a = ...
            b = ...
            L.append(...)
        return L
    
assert fibo(0) == [0]
assert fibo(1) == [0, 1]
assert fibo(7) == [0, 1, 1, 2, 3, 5, 8]


# Exercice 7
def hamming(tab1,tab2):
    """
    tab1, tab2 : listes de même longueur
    Sortie : entier - nombre d'indices i pour lesquels tab1[i] est différent de tab2[i]
    """
    compteur = 0
    for k in ...:
        if ...............:
            compteur += 1
    return compteur

assert hamming([3, 7, 2, 1, 8, 2, 9], [4, 1, 2, 1, 8, 3, 9]) == 3
assert hamming([3, 7, 2, 1, 8, 2, 9], [3, 1, 2, 1, 8, 2, 9]) == 1


# Exercice 8
def renverser(tab):
    """
    tab : liste
    Sortie : liste - liste inversée des éléments de tab (le premier élément devient le dernier, le deuxième devient l'avant dernier, etc...
    """
    tab2 = []
    for k in range(len(tab)):
        tab2.........(......)
    return tab2

assert renverser([3, 7, 2, 1, 8, 2, 9]) == [9, 2, 8, 1, 2, 7, 3]


# Exercice 9
def compte(tab,valeur):
    """
    tab : liste
    valeur : variable de même type que les éléments de tab
    Sortie : entier - nombre d'occurrences de valeur dans tab (nombre de fois où valeur est présent dans tab) 
    """
    compteur = 0
    ......
    
assert compte([2, 5, 4, 3, 6, 7, 2, 3, 9, 3], 3) == 3
assert compte([2, 5, 4, 3, 6, 7, 2, 3, 9, 3], 2) == 2
assert compte([2, 5, 4, 3, 6, 7, 2, 3, 9, 3], 1) == 0


# Exercice 10
def valeur_du_maxi(tab):
    """
    tab : liste d'éléments comparables
    Sortie : plus grand élément figurant dans tab 
    """
    maxi_temporaire = ...
    for ...... in ......:
        if ...... > ......:
            maxi_temporaire = ......
    return maxi_temporaire

assert valeur_du_maxi([2, 5, 4, 3, 6, 7, 2, 3, 9, 3]) == 9
assert valeur_du_maxi([7, 3, 5, 2, 5, 7, 0, 1]) == 7
assert valeur_du_maxi([4, 3, 5, 2, 5, 1, 0, 1]) == 5


# Exercice 11
def premier_indice_du_maxi(tab):
    """
    tab : liste non vide d'entiers
    Sortie : entier - indice de la première occurrence du plus grand élément contenu dans tab
    """
    indice_du_maxi = 0
    for k in range(len(tab)):
        if tab[...] > tab[...]:
            ...
    return indice_du_maxi

assert premier_indice_du_maxi([2, 5, 4, 3, 6, 7, 2, 3, 9, 3]) == 8
assert premier_indice_du_maxi([7, 3, 5, 2, 5, 7, 0, 1]) == 0
assert premier_indice_du_maxi([4, 3, 5, 2, 5, 1, 0, 1]) == 2


# Exercice 12
def minimum(tab):
    """
    tab : liste non vide d'entiers
    Sortie : entier, liste - valeur du minimum et liste des indices où se situe le minimum dans tab
    """
    minimum = tab[0]
    L = [0]
    for k in range(......,......):
        if tab[k] == minimum:
            .........
        elif tab[k] < minimum:
            minimum = .........
            L = .........
    return minimum,L

assert minimum([2, 5, 4, 3, 6, 7, 2, 3, 9, 3]) == (2, [0, 6])
assert minimum([7, 3, 5, 2, 5, 7, 0, 1]) == (0, [6])
assert minimum([1, 4, 3, 5, 2, 5, 1, 4, 1]) == (1, [0, 6, 8])


# Exercice 13
def ranger(tab):
    """
    tab : liste non vide d'entiers compris entre 0 et 9
    Sortie : liste de 10 éléments - nombre d'éléments de tab égaux à 0, égaux à 1, etc..., égaux à 9
    """
    L = [0,0,0,0,0,0,0,0,0,0]
    for ...... in tab:
        ...... = ......
    return L

assert ranger([0,1, 2, 3, 4, 5, 6, 7, 8, 9]) == [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
assert ranger([7, 3, 5, 2, 5, 7, 0, 1]) == [1, 1, 1, 1, 0, 2, 0, 2, 0, 0]


# Exercice 14
def premier_indice_valeur(tab,valeur):
    """
    tab : liste d'entiers
    valeur : un entier
    Sortie : entier - premier indice de valeur dans tab si valeur est un élément de tab. Renvoie None sinon
    """
    for ...... in ......:
        if ...... == ......:
            return ......
        
assert premier_indice_valeur([7, 3, 5, 2, 5, 7, 0, 1], 7) == 0
assert premier_indice_valeur([7, 3, 5, 2, 5, 7, 0, 1], 5) == 2


# Exercice 15
def produit(tab):
    """
    tab : liste non vide d'entiers
    Sortie : entier - produit des éléments de tab
    """
    resultat = ...
    for element in tab:
        if element == 0:
            ......
        else:
            resultat = ......
    return resultat

assert produit([2, 3, 1]) == 6
assert produit([7, 3, 5, 2, 5, 7, 0, 1]) == 0


# Exercice 16
def consecutifs(tab,val1,val2):
    """
    tab : liste d'entiers
    val1, val2 : deux entiers
    Sortie : booléen - True si val1 et val2 sont des éléments consécutifs de tab (dans cet ordre), False sinon
    """
    for k in range(.........):
        if tab[....] == ...... and tab[......] == ......:
            return True
    return False

assert consecutifs([7, 3, 5, 0, 5, 7, 0, 1], 5, 7) == True
assert consecutifs([7, 3, 5, 0, 5, 7, 0, 1], 5, 0) == True
assert consecutifs([7, 3, 5, 0, 5, 7, 0, 1], 0, 5) == True
assert consecutifs([7, 3, 5, 0, 5, 7, 0, 1], 7, 5) == False


# Exercice 17
def successifs(tab,val1,val2):
    """
    tab : liste d'entiers
    val1, val2 : deux entiers
    Sortie : booléen - True si val1 et val2 sont des éléments de tab (dans cet ordre), False sinon
    """
    for k in range(......):
        if tab[k] == val1:
            for i in range(...,...):
                if tab[i] == val2:
                    return True
    return False

assert successifs([7, 3, 5, 0, 5, 7, 0, 1], 3, 7) == True
assert successifs([7, 3, 5, 0, 5, 7, 0, 1], 5, 1) == True
assert successifs([7, 3, 5, 0, 5, 7, 0, 1], 1, 0) == False


# Exercice 18
def prefixe(tab1,tab2):
    """
    tab1, tab2 : deux listes d'entiers
    Sortie : booléen - True si la liste tab1 commence par les éléments de la liste tab2 dans le même ordre
    """
    for k in range(......):
        if .........   ......:
            return ......
    return ......

assert prefixe([7, 3, 5, 0, 5, 7, 0, 1], [7, 3, 5, 0]) == True
assert prefixe([7, 3, 5, 0, 5, 7, 0, 1], [7, 2, 5, 0]) == False
assert prefixe([7, 3, 5, 0, 5, 7, 0, 1], [3, 5, 0]) == False
assert prefixe([7, 3, 5, 0, 5, 7, 0, 1], [7]) == True


# Exercice 19
def suffixe(tab1,tab2):
    """
    tab1, tab2 : deux listes d'entiers
    Sortie : booléen - True si la liste tab1 finit par les éléments de la liste tab2 dans le même ordre
    """
    for k in range(......):
        if .........   ......:
            return ......
    return ......

assert suffixe([7, 3, 5, 0, 5, 7, 0, 1], [7, 0, 1]) == True
assert suffixe([7, 3, 5, 0, 5, 7, 0, 1], [1]) == True
assert suffixe([7, 3, 5, 0, 5, 7, 0, 1], [7, 0]) == False
